app.service('AppService',['$http','APP_CONFIG', function($http,APP_CONFIG) {
	var login = function(userName, password) {
		var _responsePromise = $http.get(APP_CONFIG.API_URL+"action=login&username="+userName+"&password="+password);
		return _responsePromise;
	};
	return{
		login: login
	}
}]);