app.constant('APP_CONFIG', (function() {
	return{
		API_URL: "http://217.182.90.95/api/?"
	}
})());