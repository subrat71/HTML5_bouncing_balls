app.factory('AppModel', function() {
	var userType = "",

	getUserType = function() {
		return userType;
	},
	setUserType = function(userType) {
		userType = userType ? "superAdmin" : "admin";
	};
	return{
		getUserType: getUserType,
		setUserType: setUserType
	}
});