app.controller('MainController',['$scope','AppService','AppModel','$state', function($scope,AppService,AppModel,$state) {
	$scope.userName = "test";
	$scope.password = "test";

	//Login User
	$scope.logIn = function() {
		console.log("Login Clicked!!! Validation check");
		AppService.login($scope.userName,$scope.password).then(function(response) {
			AppModel.setUserType(response.data.session[0].admin);
			if(!response.data.session[0].admin) $state.go('admin');
			else  $state.go('superAdmin');
		});
	}

	//To reset login form
	$scope.resetForm = function() {
		$scope.userName = "";
		$scope.password = "";
	}
}]);