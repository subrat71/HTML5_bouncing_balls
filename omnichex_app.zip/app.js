var app = angular.module('omnichexApp', ['ui.router']);

app.config(['$stateProvider', '$urlRouterProvider', function($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/');

	$stateProvider.state('login', {
		url: '/',
		templateUrl: '../partials/login.html',
		controller: 'MainController'
	}).state('forgotPassword', {
		url: '/forgotPassword',
		templateUrl: '../partials/resetPassword.html',
		controller: 'homeController'
	}).state('admin', {
		// abstract: true,
		url: '/admin',
		templateUrl: '../modules/admin/admin.html',
		controller: 'AdminController'
	}).state('admin.dashboard', {
		url: '/dashboard',
		templateUrl: '../modules/admin/dashboard.html',
		controller: 'DashboardController'
	}).state('admin.playback', {
		url: '/playback',
		templateUrl: '../modules/admin/playback.html',
		controller: 'PlaybackController'
	}).state('admin.tracking', {
		url: '/tracking',
		templateUrl: '../modules/admin/tracking.html',
		controller: 'TrackingController'
	}).state('admin.trips', {
		url: '/trips',
		templateUrl: '../modules/admin/trips.html',
		controller: 'TripsController'
	}).state('superAdmin', {
		url: '/superAdmin',
		templateUrl: '../modules/superAdmin/superAdmin.html',
		controller: 'SuperAdminController'
	});
}]);