app.controller('SuperAdminController', ["$scope", function($scope) {
	console.log("SuperAdminController");
}]);