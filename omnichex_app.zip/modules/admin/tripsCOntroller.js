app.controller('TripsController', ["$scope", function($scope) {
	console.log("TripsController");
}]);