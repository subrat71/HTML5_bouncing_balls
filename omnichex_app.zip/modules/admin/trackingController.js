app.controller('TrackingController', ["$scope", function($scope) {
	console.log("TrackingController");
}]);