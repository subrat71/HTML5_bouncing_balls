app.controller('DashboardController', ["$scope", function($scope) {
	console.log("DashboardController");
}]);