module.exports = function(grunt) {
	require('load-grunt-tasks')(grunt);
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		connect: {
			server: {
				options: {
					port: 3000,
					livereload: true,
					protocol:'http',
					hostname:'localhost',
					open: {
						target: 'http://localhost:3000/omnichexapp',
						appName: 'chrome',
						callback: function() {
							console.log('Target opened in Chrome');
						}
					}
				}
			}
		},
		watch: {
            options: {
                livereload: true,
            },
            dev: {
                files: ['assets/css/*.css','app**.js','mainController.js','modules/**/*.js','*.html','**/*.html','!**/omnichexapp/**','!**/gruntbuild/**'],
                tasks: ['ngAnnotate:appannotate','html2js','concat','concat_css','copy:main','copy:copyAll','copy:copyAssets'],
                options: {
                    livereload: true
                }
            }
        },
        clean: ["gruntbuild","omnichexapp"],
        copy:{
          main: {
            files:[
              {
                expand: true,
                cwd:'',
                src: ['index.html'],
                dest: 'omnichexapp/'
              }
            ]
          },
          copyAll:{
            files:[
              {
                expand: true,
                cwd:'gruntbuild',
                src: ["app.js","app.css","lib.js","allView.js"],
                dest: 'omnichexapp/'
              }
            ]
          },
          copyAssets:{
            files:[
                {
                    expand: true,
                    cwd: 'assets',
                    src: ['**'],
                    dest: 'omnichexapp/'
                }
            ]
          }
        },
        concat: {
            options: {
                // separator: ';'
            },
            libs: {
                src: [
                    "vendors/jquery.min.js",
                    "vendors/bootstrap.min.js",
                    "vendors/angular.min.js",
                    "vendors/angular-**.js",
                    "vendors/plugins/*.js"
                ],
                dest: 'gruntbuild/lib.js'
            },
            custom: {
                src: ["gruntbuild/appMain.js","gruntbuild/appController.js","gruntbuild/appService.js"],
                dest: 'gruntbuild/app.js'
            }
        },
        ngAnnotate: {
            options: {
                singleQuotes: true
            },
            appannotate: {
                files: {
                    'gruntbuild/appMain.js': ['app.js','appConfig.js'],
                    'gruntbuild/appController.js': ['MainController.js','modules/**/**Controller.js'],
                    'gruntbuild/appService.js': ['appService.js','appModel.js','modules/**/**Service.js'],
                },
            },
        },
        concat_css: {
		    options: {
		      //
		    },
		    custom:{
		    	src:['assets/css/*.css'],
		    	dest: 'gruntbuild/app.css'
		    }
		},
        html2js: {
            options: {
              // custom options, see below
            },
            main: {
              src: ['partials/*.html','modules/**/*.html'],
              dest: 'gruntbuild/allView.js'
            },
        }
        //do prod build
	});

	grunt.registerTask('default',['clean','ngAnnotate:appannotate','html2js','concat','concat_css','copy:main','copy:copyAll','copy:copyAssets','connect','watch:dev']);
	grunt.registerTask('app', ['clean','ngAnnotate:appannotate','html2js','concat','concat_css','copy:main','copy:copyAll','copy:copyAssets','connect','watch:dev']);
};